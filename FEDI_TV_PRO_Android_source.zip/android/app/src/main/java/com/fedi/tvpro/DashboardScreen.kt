package com.fedi.tvpro

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.LiveTv
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.Tv
import androidx.compose.material3.Icon
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

internal data class XtreamSession(
    val server: FediServer,
    val username: String,
    val password: String,
    val expiryTimestamp: Long?,
    val accountStatus: String,
)

@Composable
internal fun DashboardScreen(session: XtreamSession, language: String, onLogout: () -> Unit) {
    var tab by remember { mutableStateOf("live") }
    var items by remember { mutableStateOf(emptyList<XtreamItem>()) }
    var categories by remember { mutableStateOf(emptyList<XtreamCategory>()) }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<XtreamItem?>(null) }
    var playerItem by remember { mutableStateOf<XtreamItem?>(null) }
    var playerOpen by remember { mutableStateOf(false) }
    var playbackError by remember { mutableStateOf<String?>(null) }
    var episodes by remember { mutableStateOf(emptyList<XtreamItem>()) }
    var episodesLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(selected?.id, selected?.kind, session.server.baseUrl, session.username) {
        episodes = emptyList()
        if (selected?.kind == "series") {
            episodesLoading = true
            XtreamClient.loadSeriesEpisodes(session.server.baseUrl, session.username, session.password, selected!!.id)
                .onSuccess { episodes = it }
                .onFailure { episodes = emptyList() }
            episodesLoading = false
        }
    }

    LaunchedEffect(tab, selectedCategory, session.server.baseUrl, session.username) {
        loading = true
        errorMessage = null
        if (selectedCategory == null) {
            val categoryResult = XtreamClient.loadCategories(session.server.baseUrl, session.username, session.password, tab)
            categoryResult.onSuccess { categories = it }.onFailure { categories = emptyList(); errorMessage = it.message ?: "CATEGORY_ERROR" }
        }
        val contentResult = XtreamClient.loadContent(session.server.baseUrl, session.username, session.password, tab, selectedCategory)
        contentResult.onSuccess { items = it }.onFailure { errorMessage = it.message ?: "NETWORK_ERROR"; items = emptyList() }
        loading = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("FEDI TV PRO", color = FediWhite, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text(session.server.displayName, color = FediMuted, fontSize = 13.sp)
            }
            Button(onClick = onLogout, colors = ButtonDefaults.buttonColors(containerColor = FediCard), modifier = Modifier.semantics { contentDescription = fediText(language, "تسجيل الخروج", "Déconnexion", "Sign out") }) {
                Text(fediText(language, "خروج", "Quitter", "Exit"), color = FediWhite)
            }
        }

        SubscriptionBadge(session, language)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionCard(tab == "live", fediText(language, "مباشر", "Direct", "Live"), Icons.Outlined.LiveTv, Modifier.weight(1f)) { tab = "live"; selectedCategory = null }
            SectionCard(tab == "movies", fediText(language, "أفلام", "Films", "Movies"), Icons.Outlined.Movie, Modifier.weight(1f)) { tab = "movies"; selectedCategory = null }
            SectionCard(tab == "series", fediText(language, "مسلسلات", "Séries", "Series"), Icons.Outlined.Tv, Modifier.weight(1f)) { tab = "series"; selectedCategory = null }
        }
        Text(
            fediText(language, "اختر القسم", "Choisissez une section", "Choose a section"),
            color = FediMuted,
            fontSize = 14.sp,
            modifier = Modifier.semantics { contentDescription = fediText(language, "أقسام المحتوى", "Sections de contenu", "Content sections") },
        )
        if (categories.isNotEmpty()) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                item { CategoryChip(fediText(language, "الكل", "Tout", "All"), selectedCategory == null) { selectedCategory = null } }
                items(categories, key = { it.id }) { category -> CategoryChip(category.name, selectedCategory == category.id) { selectedCategory = category.id } }
            }
        }
        errorMessage?.let { Text(fediText(language, "تعذر تحميل المحتوى. حاول لاحقًا.", "Impossible de charger le contenu.", "Could not load content. Try again."), color = Color(0xFFFFB4AB)) }
        Text(if (loading) fediText(language, "جارٍ تحميل المحتوى…", "Chargement du contenu…", "Loading content…") else if (items.isEmpty()) fediText(language, "لا يوجد محتوى متاح.", "Aucun contenu disponible.", "No content available.") else fediText(language, "اختر محتوى للتشغيل", "Choisissez un contenu", "Choose content to play"), color = FediMuted)

        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            items(items, key = { "${it.kind}-${it.id}" }) { item ->
                ContentCard(item, onClick = { selected = item; playerOpen = false })
            }
        }

        selected?.let { item ->
            SelectedItemPreview(
                item = item,
                language = language,
                onPlay = {
                    playbackError = null
                    if (item.kind == "series") {
                        scope.launch {
                            XtreamClient.firstSeriesEpisode(session.server.baseUrl, session.username, session.password, item.id)
                                .onSuccess { episode ->
                                    playerItem = episode
                                    playerOpen = episode != null
                                    if (episode == null) playbackError = "NO_EPISODES"
                                }
                                .onFailure { playbackError = "PLAYBACK_ERROR" }
                        }
                    } else {
                        playerItem = item
                        playerOpen = true
                    }
                },
                onClose = { selected = null; playerItem = null; playerOpen = false },
            )
            if (item.kind == "series") {
                Text(fediText(language, "الحلقات", "Épisodes", "Episodes"), color = FediWhite, fontWeight = FontWeight.Bold)
                if (episodesLoading) {
                    Text(fediText(language, "جارٍ تحميل الحلقات…", "Chargement des épisodes…", "Loading episodes…"), color = FediMuted)
                } else if (episodes.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        items(episodes, key = { it.id }) { episode ->
                            Button(
                                onClick = { playbackError = null; playerItem = episode; playerOpen = true },
                                colors = ButtonDefaults.buttonColors(containerColor = if (playerItem?.id == episode.id) FediPurple else FediCard),
                                modifier = Modifier.semantics { contentDescription = "${fediText(language, "تشغيل الحلقة", "Lire l’épisode", "Play episode")}: ${episode.name}" },
                            ) { Text(episode.name, color = FediWhite, maxLines = 1) }
                        }
                    }
                }
            }
            playbackError?.let { reason ->
                val message = if (reason == "NO_EPISODES") {
                    fediText(language, "لا توجد حلقات قابلة للتشغيل لهذا المسلسل.", "Aucun épisode lisible pour cette série.", "No playable episodes for this series.")
                } else {
                    fediText(language, "تعذر الاتصال بالخادم لجلب الحلقات. حاول لاحقًا.", "Impossible de contacter le serveur pour charger les épisodes.", "Could not contact the server to load episodes.")
                }
                Text(message, color = Color(0xFFFFB4AB), modifier = Modifier.semantics { contentDescription = message })
            }
            if (playerOpen) {
                FediPlayer(item = playerItem ?: item, language = language, onClose = { playerOpen = false; playerItem = null })
            }
        }
    }
}

@Composable
private fun SectionCard(selected: Boolean, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Card(
        modifier = modifier.height(92.dp).onFocusChanged { focused = it.isFocused }.focusable().clickable(onClick = onClick).semantics { contentDescription = label },
        colors = CardDefaults.cardColors(containerColor = if (selected || focused) FediPurple else FediCard),
        border = if (focused) BorderStroke(2.dp, FediWhite) else null,
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, contentDescription = label, tint = FediWhite, modifier = Modifier.height(32.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(label, color = FediWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

@Composable
private fun CategoryChip(name: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = if (selected || focused) FediPurple else FediCard), modifier = Modifier.onFocusChanged { focused = it.isFocused }.focusable().semantics { contentDescription = name }) { Text(name, color = FediWhite) }
}

@Composable
private fun ContentCard(item: XtreamItem, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier.width(180.dp).height(112.dp).onFocusChanged { focused = it.isFocused }.focusable().clickable(onClick = onClick).semantics { contentDescription = item.name },
        colors = CardDefaults.cardColors(containerColor = if (focused) FediPurple else FediCard),
        border = if (focused) BorderStroke(2.dp, FediWhite) else null,
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
                model = item.posterUrl?.takeIf { it.isNotBlank() },
                placeholder = painterResource(R.drawable.fedi_logo),
                error = painterResource(R.drawable.fedi_logo),
                fallback = painterResource(R.drawable.fedi_logo),
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(72.dp).semantics { contentDescription = "${item.name} logo" },
            )
            Box(modifier = Modifier.fillMaxWidth().weight(1f).padding(12.dp), contentAlignment = Alignment.CenterStart) {
                Text(item.name, color = FediWhite, fontWeight = FontWeight.SemiBold, maxLines = 2)
            }
        }
    }
}

@Composable
private fun SubscriptionBadge(session: XtreamSession, language: String) {
    val expiryDate = session.expiryTimestamp?.let { java.util.Date(it * 1000) }
    val expired = expiryDate?.before(java.util.Date()) == true
    val suspended = session.accountStatus.equals("Suspended", ignoreCase = true) || session.accountStatus.equals("Inactive", ignoreCase = true)
    val daysLeft = expiryDate?.let { ((it.time - System.currentTimeMillis()) / 86_400_000L).coerceAtLeast(0) }
    val expiry = expiryDate?.let { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(it) }
        ?: fediText(language, "غير محدد", "Non défini", "Not provided")
    Card(colors = CardDefaults.cardColors(containerColor = FediCard), modifier = Modifier.fillMaxWidth().semantics { contentDescription = "${fediText(language, "تاريخ الانتهاء", "Expiration", "Expiry")}: $expiry" }) {
        Row(modifier = Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(if (suspended) fediText(language, "الاشتراك موقوف", "Abonnement suspendu", "Subscription suspended") else if (expired) fediText(language, "الاشتراك منتهٍ", "Abonnement expiré", "Subscription expired") else fediText(language, "الاشتراك فعال", "Abonnement actif", "Subscription active"), color = if (suspended || expired) Color(0xFFFFB4AB) else FediWhite, fontWeight = FontWeight.Bold)
            Text("${fediText(language, "الانتهاء", "Expire", "Expires")}: $expiry${daysLeft?.let { " · $it ${fediText(language, "يوم", "jours", "days")}" } ?: ""}", color = FediMuted)
        }
    }
}

@Composable
private fun SelectedItemPreview(item: XtreamItem, language: String, onPlay: () -> Unit, onClose: () -> Unit) {
    val kindLabel = when (item.kind) {
        "live" -> fediText(language, "بث مباشر", "Direct", "Live")
        "movies" -> fediText(language, "فيلم", "Film", "Movie")
        else -> fediText(language, "مسلسل", "Série", "Series")
    }
    Card(colors = CardDefaults.cardColors(containerColor = FediCard), modifier = Modifier.fillMaxWidth().semantics { contentDescription = "${item.name}, $kindLabel" }) {
        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = item.posterUrl?.takeIf { it.isNotBlank() }, placeholder = painterResource(R.drawable.fedi_logo), error = painterResource(R.drawable.fedi_logo), fallback = painterResource(R.drawable.fedi_logo), contentDescription = item.name, contentScale = ContentScale.Crop, modifier = Modifier.width(88.dp).height(58.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(item.name, color = FediWhite, fontWeight = FontWeight.Bold, maxLines = 2)
                Text(kindLabel, color = FediMuted, fontSize = 12.sp)
            }
            Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = FediPurple), modifier = Modifier.semantics { contentDescription = fediText(language, "تشغيل", "Lire", "Play") }) { Text(fediText(language, "تشغيل", "Lire", "Play"), color = FediWhite) }
            Button(onClick = onClose, colors = ButtonDefaults.buttonColors(containerColor = FediCard), modifier = Modifier.semantics { contentDescription = fediText(language, "إغلاق المعاينة", "Fermer l’aperçu", "Close preview") }) { Text(fediText(language, "إغلاق", "Fermer", "Close"), color = FediWhite) }
        }
    }
}

@Composable
private fun FediPlayer(item: XtreamItem, language: String, onClose: () -> Unit) {
    BackHandler(enabled = true, onBack = onClose)
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(item.streamUrl) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(Uri.parse(item.streamUrl))); prepare(); playWhenReady = true } }
    androidx.compose.runtime.DisposableEffect(player) { onDispose { player.release() } }
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(item.name, color = FediWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxWidth().height(220.dp).semantics { contentDescription = item.name })
        Button(onClick = onClose, colors = ButtonDefaults.buttonColors(containerColor = FediPurple), modifier = Modifier.semantics { contentDescription = fediText(language, "إغلاق المشغل", "Fermer le lecteur", "Close player") }) { Text(fediText(language, "إغلاق", "Fermer", "Close")) }
    }
}

