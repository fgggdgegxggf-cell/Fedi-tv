package com.fedi.tvpro

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

internal data class XtreamLoginResult(
    val success: Boolean,
    val message: String,
    val username: String? = null,
    val expiryTimestamp: Long? = null,
    val accountStatus: String = "",
)

internal data class XtreamCategory(val id: String, val name: String)

internal data class XtreamItem(
    val id: String,
    val name: String,
    val streamUrl: String,
    val posterUrl: String? = null,
    val categoryId: String? = null,
    val kind: String,
)

internal object XtreamClient {
    suspend fun login(baseUrl: String, username: String, password: String): XtreamLoginResult = withContext(Dispatchers.IO) {
        runCatching {
            val json = requestJson(baseUrl, username, password)
            val userInfo = json.optJSONObject("user_info")
            val auth = userInfo?.optInt("auth", 0) == 1
            val status = userInfo?.optString("status", "") ?: ""
            val expiry = userInfo?.optString("exp_date", "")?.toLongOrNull()
            if (auth && status.isNotBlank()) XtreamLoginResult(true, status, username, expiry, status)
            else XtreamLoginResult(false, "INVALID_CREDENTIALS", accountStatus = status)
        }.getOrElse { error -> XtreamLoginResult(false, error.message ?: "NETWORK_ERROR") }
    }

    suspend fun loadCategories(baseUrl: String, username: String, password: String, kind: String): Result<List<XtreamCategory>> = withContext(Dispatchers.IO) {
        runCatching {
            val action = when (kind) { "live" -> "get_live_categories"; "movies" -> "get_vod_categories"; else -> "get_series_categories" }
            val json = requestArray(baseUrl, username, password, action)
            buildList {
                for (index in 0 until json.length()) {
                    val item = json.optJSONObject(index) ?: continue
                    val id = item.optString("category_id").ifBlank { item.optString("id") }
                    val name = item.optString("category_name").ifBlank { item.optString("name") }
                    if (id.isNotBlank() && name.isNotBlank()) add(XtreamCategory(id, name))
                }
            }
        }
    }

    suspend fun loadContent(baseUrl: String, username: String, password: String, kind: String, categoryId: String? = null): Result<List<XtreamItem>> = withContext(Dispatchers.IO) {
        runCatching {
            val action = when (kind) { "live" -> "get_live_streams"; "movies" -> "get_vod_streams"; else -> "get_series" }
            val json = requestArray(baseUrl, username, password, action, categoryId)
            buildList {
                for (index in 0 until json.length()) {
                    val item = json.optJSONObject(index) ?: continue
                    val id = item.optString("stream_id").ifBlank { item.optString("series_id") }.ifBlank { item.optString("id") }
                    val name = item.optString("name").ifBlank { "FEDI TV" }
                    if (id.isNotBlank()) {
                        val streamUrl = when (kind) {
                            "live" -> baseUrl.trimEnd('/') + "/live/$username/$password/$id.m3u8"
                            "movies" -> baseUrl.trimEnd('/') + "/movie/$username/$password/$id.mp4"
                            else -> baseUrl.trimEnd('/') + "/series/$username/$password/$id.mp4"
                        }
                        add(XtreamItem(id, name, streamUrl, item.optString("stream_icon").ifBlank { null }, item.optString("category_id").ifBlank { null }, kind))
                    }
                }
            }
        }
    }

    suspend fun loadSeriesEpisodes(baseUrl: String, username: String, password: String, seriesId: String): Result<List<XtreamItem>> = withContext(Dispatchers.IO) {
        runCatching {
            val json = requestObject(baseUrl, username, password, "get_series_info", seriesId)
            val episodes = json.optJSONObject("episodes") ?: return@runCatching emptyList()
            val result = mutableListOf<XtreamItem>()
            val seasonKeys = episodes.keys().asSequence().toList().sortedWith(compareBy { it.toIntOrNull() ?: Int.MAX_VALUE })
            for (seasonKey in seasonKeys) {
                val season = episodes.optJSONArray(seasonKey) ?: continue
                for (index in 0 until season.length()) {
                    val episode = season.optJSONObject(index) ?: continue
                    val episodeId = episode.optString("id").ifBlank { episode.optString("episode_id") }
                    if (episodeId.isBlank()) continue
                    val extension = episode.optString("container_extension").ifBlank { "mp4" }
                    val episodeNumber = episode.optString("episode_num").ifBlank { (index + 1).toString() }
                    val name = episode.optString("title").ifBlank { episode.optString("name") }.ifBlank { "S$seasonKey · E$episodeNumber" }
                    val url = baseUrl.trimEnd('/') + "/series/$username/$password/$episodeId.$extension"
                    result += XtreamItem(episodeId, "S$seasonKey · E$episodeNumber · $name", url, null, seriesId, "series")
                }
            }
            result
        }
    }

    suspend fun firstSeriesEpisode(baseUrl: String, username: String, password: String, seriesId: String): Result<XtreamItem?> =
        loadSeriesEpisodes(baseUrl, username, password, seriesId).map { it.firstOrNull() }

    private fun requestJson(baseUrl: String, username: String, password: String): JSONObject = JSONObject(requestBody(baseUrl, username, password, null))
    private fun requestObject(baseUrl: String, username: String, password: String, action: String, seriesId: String): JSONObject = JSONObject(requestBody(baseUrl, username, password, action, null, seriesId))
    private fun requestArray(baseUrl: String, username: String, password: String, action: String, categoryId: String? = null): JSONArray = JSONArray(requestBody(baseUrl, username, password, action, categoryId))

    private fun requestBody(baseUrl: String, username: String, password: String, action: String?, categoryId: String? = null, seriesId: String? = null): String {
        val query = "username=${URLCodec.encode(username)}&password=${URLCodec.encode(password)}" + (action?.let { "&action=${URLCodec.encode(it)}" } ?: "") + (categoryId?.let { "&category_id=${URLCodec.encode(it)}" } ?: "") + (seriesId?.let { "&series_id=${URLCodec.encode(it)}" } ?: "")
        val connection = (URL(baseUrl.trimEnd('/') + "/player_api.php?$query").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 15_000
            instanceFollowRedirects = true
        }
        if (connection.responseCode !in 200..299) error("HTTP_${connection.responseCode}")
        return connection.inputStream.bufferedReader().use { it.readText() }
    }
}

private object URLCodec {
    fun encode(value: String): String = java.net.URLEncoder.encode(value, Charsets.UTF_8.name())
}
