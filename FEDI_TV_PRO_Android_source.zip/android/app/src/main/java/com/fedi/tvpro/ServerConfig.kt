package com.fedi.tvpro

import android.content.Context
import android.net.Uri
import org.json.JSONArray

internal data class FediServer(
    val id: String,
    val displayName: String,
    val baseUrl: String,
)

internal data class ServerLoadOutcome(
    val servers: List<FediServer>,
    val invalidEntries: Int,
)

internal object ServerConfig {
    fun loadDetailed(context: Context): Result<ServerLoadOutcome> = runCatching {
        val json = context.assets.open("servers.json").bufferedReader().use { it.readText() }
        val array = JSONArray(json)
        val seenIds = mutableSetOf<String>()
        val seenUrls = mutableSetOf<String>()
        var invalidEntries = 0

        val servers = buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index)
                val id = item?.optString("id")?.trim().orEmpty()
                val name = item?.optString("displayName")?.trim().orEmpty()
                val url = item?.optString("baseUrl")?.trim()?.trimEnd('/').orEmpty()
                val parsed = Uri.parse(url)
                val scheme = parsed.scheme?.lowercase()
                val host = parsed.host
                val port = parsed.port
                val validPort = port == -1 || port in 1..65535
                val validUrl = (scheme == "http" || scheme == "https") && host != null && validPort
                val unique = seenIds.add(id.lowercase()) && seenUrls.add(url.lowercase())

                if (id.isNotEmpty() && name.isNotEmpty() && validUrl && unique) {
                    add(FediServer(id, name, url))
                } else {
                    invalidEntries += 1
                    seenIds.remove(id.lowercase())
                    seenUrls.remove(url.lowercase())
                }
            }
        }
        ServerLoadOutcome(servers, invalidEntries)
    }

    fun loadResult(context: Context): Result<List<FediServer>> =
        loadDetailed(context).map { it.servers }

    fun load(context: Context): List<FediServer> = loadResult(context).getOrDefault(emptyList())
}
